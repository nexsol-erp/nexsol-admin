# @tradelink247/mindmap-renderer

The React Flow canvas shared by the standalone Mind Map app and TradeLink247's Product 360.

One rendering implementation, two very different products on top of it.

---

## What it owns, and what it does not

**It owns the canvas.** Node measurement retention, selection accounting, edge projection,
readonly enforcement, background/controls/minimap chrome, and the scoped stylesheet.

**It does not own what a node looks like.** The node component is a prop.

That boundary is deliberate and it is the main design decision in this package. The two
consumers draw genuinely different things — the mind map shows a title, tags and links; Product
360 shows metrics, severity and evidence links. A single component doing both would serve
neither, and it would drag one host's design system into a package the other host also uses.

The most valuable thing here is not the layout code. It is this, from the original canvas and
carried over intact:

> React Flow measures each node in the DOM and reports the result as a `dimensions` change.
> That measurement has to be held and handed back on the nodes we give it: when it adopts a
> node object with no `measured` field it resets that node's `handleBounds`, and an edge whose
> endpoints have no `handleBounds` is not drawn at all. Because the array is rebuilt from the
> source data on every render, dropping the measurements makes every connection blink out for
> the duration of a drag.

That is the kind of knowledge worth having in exactly one place.

---

## No MUI. Ever.

The package has **no dependency on `@mui/material`**, not even a peer one, and a build-time
check asserts that `dist/` contains no reference to it.

The reason is concrete rather than stylistic. The standalone app runs **MUI v6.2**; the
TradeLink247 admin runs **MUI v5.16**. Two copies of `@mui/material` in one bundle means two
`ThemeContext` objects — and a v6 component inside a v5 `ThemeProvider` does **not** throw. It
silently falls back to MUI's default theme. The map would render with default colours inside a
dark-themed app and nothing anywhere would report an error.

So colours arrive as plain data (`RendererTheme`), and each host passes its own.

---

## Install

```jsonc
// consumer package.json
{
  "dependencies": {
    "@tradelink247/mindmap-renderer": "file:../packages/mindmap-renderer",
    "@xyflow/react": "^12"
  }
}
```

`react`, `react-dom` and `@xyflow/react` are **peer** dependencies, so a page never loads two
copies of React or of the graph engine.

The package ships **pre-built** — ESM, CJS and `.d.ts`. Create React App 5 cannot compile
TypeScript from `node_modules`, and the admin is a plain-JavaScript app; shipping source would
put a TypeScript toolchain on the wrong side of the boundary.

---

## Usage

```tsx
import { MindMapRenderer, LIGHT_THEME } from '@tradelink247/mindmap-renderer';

<MindMapRenderer
  nodes={nodes}                 // { id, x, y, data, width?, height?, zIndex? }
  edges={edges}                 // { id, source, target, shape?, label?, color? }
  nodeComponent={MyNode}        // your component; receives NodeProps<RendererFlowNode<T>>
  theme={LIGHT_THEME}           // or your own tokens
  mode="readonly"               // 'editable' | 'readonly'
  accentOf={(data) => data.color}
  highlightedIds={searchHits}
  labels={{ connectHint: t('Click a node to connect') }}
  onNodeClick={handleClick}
  onNodesMove={handleMove}
  onNavigate={handleNavigate}
/>
```

### Your node component

```tsx
import type { NodeProps } from '@xyflow/react';
import type { RendererFlowNode } from '@tradelink247/mindmap-renderer';

function MyNode({ data, selected }: NodeProps<RendererFlowNode<MyPayload>>) {
  // data.payload      - your node data, untouched
  // data.isHighlighted - in highlightedIds
  // data.mode          - 'editable' | 'readonly'
  // data.onExpand / data.onNavigate - call these; never navigate yourself
}
```

---

## Readonly is structural

`mode="readonly"` does not hide affordances, it removes them:

- no `onConnect` handler is passed to React Flow at all — not one that returns early, so
  there is no path by which a stray call could create an edge
- `nodesConnectable={false}`, `edgesFocusable={false}`, edges marked not deletable
- removal changes are dropped even if React Flow emits one
- `deleteKeyCode` is unbound in **both** modes

**Moving nodes stays allowed in readonly**, deliberately. That is layout, not data: a reader
may arrange the graph to suit themselves without being able to change what it says — which is
exactly what a saved personal layout depends on.

---

## Navigation

The renderer never opens a URL, never builds one, and never touches `window.location`. It
hands the host a typed intent through `onNavigate`, because only the host can check whether
this user is allowed to go there. There is a test asserting it.

---

## Resilience

- **`maxNodes`** (default 500) caps a runaway payload and fires `onOverflow` rather than
  freezing the tab.
- An edge whose endpoint was trimmed is **dropped**, not drawn as a stub going nowhere — a
  half-edge reads as corruption, an absent edge reads as truncation.
- An empty graph renders cleanly.
- `withAlpha` returns an unparseable colour unchanged instead of throwing: a slightly wrong
  colour is a far better failure than a canvas that will not render.
- `prefers-reduced-motion` disables transitions.

---

## Build and release

```bash
npm run build      # dist/index.js (ESM), dist/index.cjs, dist/index.d.ts
npm run test
npm run typecheck
```

Both consumers pin an exact version. To release a change:

1. `npm run build && npm run test`
2. Bump `version` in `package.json`
3. Re-install in each consumer so the built output is picked up
4. Run **the standalone app's own test suite** — it is the regression gate for this package

Publishing to a private registry is the eventual path; until one exists, consumers use a
`file:` dependency in development and a committed tarball for production.
